import React, { useState } from 'react';
import './Header.css';

const Header = () => {
    const [isOpen, setIsOpen] = useState(false);

    const toggleMenu = () => {
        setIsOpen(!isOpen);
    };

    return (
        <header className={`header ${isOpen ? 'open' : ''}`}>
            <div className="logo">
                <h1>로고</h1>
            </div>
            <nav className="nav">
                <ul>
                    <li><a href="#home">홈</a></li>
                    <li><a href="#about">알림장</a></li>
                    <li><a href="#services">프린트</a></li>
                    <li><a href="#contact">로그인</a></li>
                </ul>
            </nav>
            <button className="menu-toggle" onClick={toggleMenu}>
                <span className="bar"></span>
                <span className="bar"></span>
                <span className="bar"></span>
            </button>
        </header>
    );
};

export default Header;


